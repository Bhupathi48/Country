import os
import datetime

def createTestResultFolder():
    currentDT = str(datetime.datetime.now().strftime('%Y_%b_%d_%H_%M_%S'))
    folderName = 'testResults_'+str(currentDT)
    #filePath = r"C:\Users\ID73414\PycharmProjects\TestProject\LNT-TestCases\results"
    #filePath = r'../../LNT-TestCases/results'
    filePath = r'../TestCases/results'
    #filePath = r'LNT-TestCases/results'
    try:
        # Create target Directory
        os.mkdir(filePath+str('/')+folderName)
        #os.mkdir(filePath+folderName)
        print("Directory ", folderName,  " Created ")
        return folderName
    except FileExistsError:
        print("Directory ", folderName,  " is not created")
        return False



# def printme():
#    "This prints a passed string into this function"
#    print("hello world")
#    return;
#    conn = pypyodbc.connect(r'DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};'r'DBQ=D:\Navigator_RobotScript_POC\POCScript\TestData\NavigatorPOC_TestData;')
#    cursor = conn.cursor()
#    cursor.execute('select * from eTestCase')
#    for row in cursor.fetchall():
#       print(row)
