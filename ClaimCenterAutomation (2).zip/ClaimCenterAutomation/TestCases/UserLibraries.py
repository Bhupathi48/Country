import time
import unittest
from SeleniumLibrary import SeleniumLibrary
from SeleniumLibrary.base import keyword, LibraryComponent
from SeleniumLibrary.keywords import WaitingKeywords, ElementKeywords, FormElementKeywords, SelectElementKeywords
from robot.api import logger
from robot.libraries.BuiltIn import BuiltIn
from selenium.common.exceptions import StaleElementReferenceException, ElementClickInterceptedException, \
    MoveTargetOutOfBoundsException, ElementNotInteractableException, ElementNotSelectableException, WebDriverException, \
    ElementNotVisibleException
from selenium.webdriver import ActionChains
from selenium.webdriver.support import wait

wait.POLL_FREQUENCY = 0.1


class MyTestCase(unittest.TestCase):
    def test_something(self):
        self.assertEqual(True, False)


def get_robot_variable(variable_name):
    """Get variable value, set during run-time in robot framework"""
    try:
        return str(BuiltIn().get_variable_value(variable_name)).strip()
    except Exception as e:
        write_to_console(str(e))
        write_to_console(f'Value not found for variable : {variable_name}')
        return ""


def write_to_console(msg):
    """Print to PyCharm / IDLE Console and not logs"""
    try:
        logger.console(msg)
    except:
        print(msg)


def draw_with_action(action, element, offset_list, scale=1):
    """Draw lines on screen based on list of offsets provided"""
    action.click_and_hold(element)
    for offset in offset_list:
        action.move_by_offset(scale * offset[0], scale * offset[1])
        time.sleep(0.25)
    action.release().perform()


class BrowserKeywordsSign(LibraryComponent):

    def __init__(self, ctx):
        LibraryComponent.__init__(self, ctx)

    @keyword
    def mouse_out_sign(self, locator):
        """
        Moves mouse within element area
        :param locator:
        :return:
        """
        self.info("Simulating Mouse Out on element '%s'." % locator)
        element = self.find_element(locator)
        size = element.size
        offsetx = (size['width'] / 3) + 4
        offsety = (size['height'] / 3) + 4
        action = ActionChains(self.driver)
        action.move_to_element(element).move_by_offset(offsetx, offsety)
        action.perform()

    @keyword
    def add_signature(self, locator):
        """
        Adds signature within element area
        :param locator: Element on which Signature needs to be added
        :return: None
        """
        self.info("Simulating signature element '%s'." % locator)
        try:
            element = self.find_element(locator)
            action = ActionChains(self.driver)
            action.move_to_element(element).perform()
            draw_with_action(action, element, [(0, 20), (0, 5), (20, 0), (0, -5), (0, -20), (0, -5), (-20, 0), (0, 10)])
            draw_with_action(action, element, [(70, 0), (5, 0), (0, 25), (-20, 0), (0, -5)])
            draw_with_action(action, element, [(0, 60), (0, 10), (75, 0), (0, -10), (-5, 0)])
        except Exception as e:
            write_to_console(str(e))
            self.info(f'Exception during signature: {e}')


class BrowserKeywordsWait(LibraryComponent):
    def __init__(self, ctx):
        LibraryComponent.__init__(self, ctx)

    @keyword
    def wait_for_js(self, timeout: int = 30) -> None:
        """
        Waits until javascript in the background completes loading.
        Useful to avoid hard coded sleep methods.

        :Args:
        :param timeout: overriding timeout. Default 30 seconds
        :return: none

        :Usage:
            wait_for_js(45)
            Wait For JS  45
        """
        wait_time = timeout

        def wait_till_loop(js_command, max_timeout, loop_frequency):
            """waits till times out or js command returns False.
            js_command should return False when page load completes"""
            is_loading = self.driver.execute_script(js_command)
            while max_timeout > 0 and is_loading:
                time.sleep(loop_frequency)
                max_timeout = max_timeout - loop_frequency
                is_loading = self.driver.execute_script(js_command)
            return max_timeout

        try:
            js_cmd = "return (document.readyState != 'complete')"
            jquery_cmd = "return (jQuery.active != 0)"
            # write_to_console("Waiting until JS completes loading")
            timeout = wait_till_loop(js_cmd, timeout, 0.1)
            if self.driver.execute_script("return (typeof(jQuery) != 'undefined')"):
                timeout = wait_till_loop(jquery_cmd, timeout, 0.1)
        except:
            pass
        try:
            prod_cmd = "return (document.getElementById('processing').style.display != 'none')"
            # spotlightText isn't dynamic in Prod or any NPE that has the production.properties set
            if self.driver.execute_script("return (document.getElementById('processing') != null)"):
                timeout = wait_till_loop(prod_cmd, timeout, 0.2)
        except:
            pass
        finally:
            self.info(f'Waited for {(wait_time - timeout):.2f}s for JS to load.')

    @keyword
    def wait_until_element_is_ready(self, locator, timeout=None, error=None):
        """
        Waits until element is visible and enabled
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        self.wait_for_js(30)
        self.info("Waiting until the element '%s' is visible and enabled." % locator)
        try:
            self.scroll_to_element(locator)
            waiting_management = WaitingKeywords(self.ctx)
            waiting_management.wait_until_element_is_visible(locator, timeout, error)
            waiting_management.wait_until_element_is_enabled(locator)
        except ElementNotVisibleException as e:
            raise e
        except:
            pass

    @keyword
    def wait_until_element_is_ready_and_click_element(self, locator, timeout=None, error=None):
        """
        Waits until element is visible, enabled and then click the element
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        self.info("Waiting until the element '%s' is visible, enabled and then clicking." % locator)
        self.wait_until_element_is_ready(locator, timeout, error)
        try:
            ElementKeywords(self.ctx).click_element(locator)
        except (StaleElementReferenceException, ElementClickInterceptedException,
                ElementNotInteractableException, ElementNotSelectableException, WebDriverException) as e:
            self.info("Caught " + type(e).__name__ + ". Retrying.")
            self.click_element_with_js(locator, timeout, error)

    @keyword
    def click_element_with_action(self, locator, timeout=None, error=None):
        """
        Perform click action on the element using ActionChains
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        try:
            self.wait_until_element_is_ready(locator, timeout, error)
            self.info("Clicking using Action Chains")
            element = self.find_element(locator)
            action = ActionChains(self.driver)
            action.move_to_element(element).click().perform()
        except (StaleElementReferenceException, ElementClickInterceptedException,
                ElementNotInteractableException, ElementNotSelectableException, MoveTargetOutOfBoundsException) as e:
            self.info("Caught " + type(e).__name__ + ". Error clicking using Actions.")

    @keyword
    def click_element_with_js(self, locator, timeout=None, error=None):
        """
        Perform click action on the element using JavaScript
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        try:
            self.wait_until_element_is_ready(locator, timeout, error)
            self.info("Clicking using Javascript Executor")
            element = self.find_element(locator)
            if element:
                self.driver.execute_script("arguments[0].click();", element)
            else:
                self.info("Element '%s' is not found" % locator)
        except Exception as e:
            self.info("Caught " + type(e).__name__ + ". Error clicking using JS. Retrying.")
            self.click_element_with_action(locator, timeout, error)

    @keyword
    def wait_until_element_is_ready_and_click_button(self, locator, timeout=None, error=None):
        """
        Waits until element is visible, enabled and then click the button
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        self.info("Waiting until the button '%s' is visible, enabled and then clicking." % locator)
        self.wait_until_element_is_ready(locator, timeout, error)
        try:
            ElementKeywords(self.ctx).click_button(locator)
        except (StaleElementReferenceException, ElementClickInterceptedException,
                ElementNotInteractableException, ElementNotSelectableException) as e:
            self.info("Caught " + type(e).__name__ + ". Retrying.")
            self.click_element_with_js(locator, timeout, error)

    @keyword
    def wait_until_element_is_ready_and_click_link(self, locator, timeout=None, error=None):
        """
        Waits until element is visible, enabled and then click the link
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        self.info("Waiting until the link '%s' is visible, enabled and then clicking." % locator)
        self.wait_until_element_is_ready(locator, timeout, error)
        try:
            ElementKeywords(self.ctx).click_link(locator)
        except (StaleElementReferenceException, ElementClickInterceptedException,
                ElementNotInteractableException, ElementNotSelectableException) as e:
            self.info("Caught " + type(e).__name__ + ". Retrying.")
            self.click_element_with_js(locator, timeout, error)

    @keyword
    def wait_until_element_is_ready_and_select_from_list_by_value(self, locator, value='default', timeout=None,
                                                                  error=None):
        """
        Waits until element is visible, enabled and then choose the selected value
        :param value:
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        if value == 'default' or value == '':
            return
        self.info("Waiting until the list is visible, enabled and then clicking selecting the value '%s'." % value)
        self.wait_until_element_is_ready(locator, timeout, error)
        try:
            SelectElementKeywords(self.ctx).select_from_list_by_value(locator, value)
            self.wait_until_element_is_ready(locator, timeout, error)
            selected = SelectElementKeywords(self.ctx).get_selected_list_value(locator)
            if value != selected:
                SelectElementKeywords(self.ctx).select_from_list_by_value(locator, value)
        except (StaleElementReferenceException, ElementClickInterceptedException,
                ElementNotInteractableException, ElementNotSelectableException) as e:
            self.info("Caught " + type(e).__name__ + ". Retrying.")
            self.wait_until_element_is_ready(locator, timeout, error)
            SelectElementKeywords(self.ctx).select_from_list_by_value(locator, value)

    @keyword
    def wait_until_element_is_ready_and_select_from_list_by_index(self, locator, value='default', timeout=None,
                                                                  error=None):
        """
        Waits until element is visible, enabled and then choose the selected index
        :param value:
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        if value == 'default' or value == '':
            return
        self.info("Waiting until the list is visible, enabled and then clicking selecting the index '%s'." % value)
        self.wait_until_element_is_ready(locator, timeout, error)
        try:
            SelectElementKeywords(self.ctx).select_from_list_by_index(locator, value)
        except (StaleElementReferenceException, ElementClickInterceptedException,
                ElementNotInteractableException, ElementNotSelectableException) as e:
            self.info("Caught " + type(e).__name__ + ". Retrying.")
            self.wait_until_element_is_ready(locator, timeout, error)
            SelectElementKeywords(self.ctx).select_from_list_by_index(locator, value)

    @keyword
    def wait_until_element_is_ready_and_select_from_list_by_label(self, locator, value='default', timeout=None,
                                                                  error=None):
        """
        Waits until element is visible, enabled and then choose the selected label
        :param value:
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        if value == 'default' or value == '':
            return
        self.info("Waiting until the list is visible, enabled and then clicking selecting the label '%s'." % value)
        self.wait_until_element_is_ready(locator, timeout, error)
        try:
            SelectElementKeywords(self.ctx).select_from_list_by_label(locator, value)
            self.wait_until_element_is_ready(locator, timeout, error)
            selected = SelectElementKeywords(self.ctx).get_selected_list_label(locator)
            if value != selected:
                SelectElementKeywords(self.ctx).select_from_list_by_label(locator, value)
        except (StaleElementReferenceException, ElementClickInterceptedException,
                ElementNotInteractableException, ElementNotSelectableException) as e:
            self.info("Caught " + type(e).__name__ + ". Retrying.")
            self.wait_until_element_is_ready(locator, timeout, error)
            SelectElementKeywords(self.ctx).select_from_list_by_label(locator, value)

    @keyword
    def wait_until_element_is_ready_and_input_text(self, locator, value='default', timeout=None, error=None):
        """
        Waits until element is visible, enabled and then input text
        :param value: value to be entered in text box
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        if value == 'default' or value == '':
            return
        self.info("Waiting until the element is visible, enabled and then entering '%s'." % value)
        self.wait_until_element_is_ready(locator, timeout, error)
        try:
            FormElementKeywords(self.ctx).input_text(locator, value)
        except (StaleElementReferenceException, ElementClickInterceptedException,
                ElementNotInteractableException, ElementNotSelectableException) as e:
            self.info("Caught " + type(e).__name__ + ". Retrying.")
            self.wait_until_element_is_ready(locator, timeout, error)
            ElementKeywords(self.ctx).clear_element_text(locator)
            FormElementKeywords(self.ctx).input_text(locator, value)

    @keyword
    def wait_until_element_is_ready_and_press_keys(self, locator, *keys, timeout=None, error=None):
        """
        Waits until element is visible, enabled and then pressing the given keys
        :param keys: value to be entered in text box
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        first_item = keys[0]
        if first_item == 'default' or first_item == '':
            return
        self.info("Waiting until the element is visible, enabled and then entering '%s'." % keys)
        self.wait_until_element_is_ready(locator, timeout, error)
        try:
            ElementKeywords(self.ctx).press_keys(locator, keys)
        except (StaleElementReferenceException, ElementClickInterceptedException,
                ElementNotInteractableException, ElementNotSelectableException) as e:
            self.info("Caught " + type(e).__name__ + ". Retrying.")
            self.wait_until_element_is_ready(locator, timeout, error)
            ElementKeywords(self.ctx).clear_element_text(locator)
            ElementKeywords(self.ctx).press_keys(locator, keys)

    @keyword
    def wait_until_element_is_ready_and_scroll_element_into_view(self, locator, timeout=None, error=None):
        """
        Waits until element is visible, enabled and then scroll it into view.
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        self.info("Waiting until the element '%s' is visible, enabled and then scrolling into view." % locator)
        self.wait_until_element_is_ready(locator, timeout, error)
        self.scroll_to_element(locator)

    @keyword
    def scroll_to_element(self, locator):
        """
        Scroll to element even if out of viewport (also workaround for firefox)
        :param locator: element locator
        """
        try:
            element = self.find_element(locator)
            scroll = "arguments[0].scrollIntoView({behavior: 'auto', block: 'center', inline: 'center'});"
            self.driver.execute_script(scroll, element)
        except:
            try:
                ElementKeywords(self.ctx).scroll_element_into_view(locator)
            except:
                x = ElementKeywords(self.ctx).get_horizontal_position(locator)
                y = ElementKeywords(self.ctx).get_vertical_position(locator)
                self.driver.execute_script(f'window.scrollTo({x}, {y});')

    @keyword
    def wait_until_element_is_ready_and_select_radio_button(self, locator, value='default', timeout=None, error=None):
        """
        Waits until element is visible, enabled and then select the given radio button value
        :param value:  value to be selected in radiobutton
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        if value == 'default' or value == '':
            return
        self.info("Waiting until the radio button is visible, enabled and then selecting the '%s' value." % value)
        self.wait_until_element_is_ready(locator, timeout, error)
        try:
            FormElementKeywords(self.ctx).select_radio_button(locator, value)
        except (StaleElementReferenceException, ElementClickInterceptedException,
                ElementNotInteractableException, ElementNotSelectableException) as e:
            self.info("Caught " + type(e).__name__ + ". Retrying.")
            self.wait_until_element_is_ready(locator, timeout, error)
            FormElementKeywords(self.ctx).select_radio_button(locator, value)

    # Added by swetha for checkbox
    @keyword
    def wait_until_element_is_ready_and_select_or_Unselect_checkbox(self, locator, value='default', timeout=None,
                                                                    error=None):
        """
        Waits until element is visible, enabled and then check or uncheck the checkbox
        :param value:  value to be selected in radiobutton
        :param locator: element locator
        :param timeout: overriding timeout
        :param error: used to overwrite default error message
        :return:
        """
        if value == 'default' or value == '':
            return
        self.info("Waiting until the checkbox is visible, enabled and then checking - '%s'." % value)
        self.wait_until_element_is_ready(locator, timeout, error)
        try:
            CustomElementSelect(self.ctx).select_or_Unselect_checkbox(locator, value)
        except (StaleElementReferenceException, ElementClickInterceptedException,
                ElementNotInteractableException, ElementNotSelectableException) as e:
            self.info("Caught " + type(e).__name__ + ". Retrying.")
            self.wait_until_element_is_ready(locator, timeout, error)
            CustomElementSelect(self.ctx).select_or_Unselect_checkbox(locator, value)

    @keyword
    def wait_until_multiple_windows_are_open(self, timeout=20):
        """
        Waits until more than one browser window is open.
        This method checks the window count every second till maximum timeout

        :Args:
        :param timeout: overriding timeout. Default 20 seconds
        :return: number of windows open

        :Usage:
            wait_until_multiple_windows_are_open(30)
            Wait Until Multiple Windows Are Open
        """
        wait_time = timeout
        window_count = 0
        try:
            window_count = len(self.driver.window_handles)
            while timeout > 0 and window_count <= 1:
                time.sleep(0.5)
                timeout = timeout - 0.5
                window_count = len(self.driver.window_handles)
        except:
            pass
        self.info(f'Waited for {(wait_time - timeout):.2f}s. Windows open = {window_count}')
        return window_count


class ElementPresentAndAct(LibraryComponent):
    def __init__(self, ctx):
        LibraryComponent.__init__(self, ctx)

    @keyword
    def is_present(self, locator):
        """
        Checks if element with given locator is visible and enabled
        :param locator:
        :return:
        """
        BrowserKeywordsWait(self.ctx).wait_for_js()
        self.info("Waiting until the element '%s' is visible and enabled." % locator)
        presenceStatus = self.is_visible(locator) and self.is_element_enabled(locator)
        self.info("The presence of element '%s' is '%s'." % (locator, presenceStatus))
        return False if presenceStatus is None else presenceStatus

    @keyword
    def if_present_select_radio_button(self, locator, value='default'):
        """
        If radio button is present (visible and enabled) choose given radio button value. No value passed will leave as
        radio button's default value
        :param locator:
        :param value:
        :return:
        """
        if value == 'default' or value == '':
            return
        if self.is_present(locator):
            self.info("Radio button is present so selecting '%s'." % value)
            FormElementKeywords(self.ctx).select_radio_button(locator, value)

    # Added by swetha for checkbox
    @keyword
    def if_present_select_checkbox(self, locator, value='default'):
        """
        If checkbox is present (visible and enabled) check or uncheck the checkbox based on the value
        :param locator:
        :param value:
        :return:
        """
        if value == 'default' or value == '':
            return
        if self.is_present(locator):
            self.info("Checkbox is present so selecting '%s'." % value)
            CustomElementSelect(self.ctx).select_or_Unselect_checkbox(locator, value)

    @keyword
    def if_present_select_from_list_by_value(self, locator, value='default'):
        """
        If select is present (visible and enabled) choose the selected value. No value passed in will leave
        select as default.
        :param locator:
        :param value:
        :return:
        """
        if value == 'default' or value == '':
            return
        if self.is_present(locator):
            self.info("List is present so selecting value '%s'." % value)
            try:
                SelectElementKeywords(self.ctx).select_from_list_by_value(locator, value)
            except (StaleElementReferenceException, ElementClickInterceptedException,
                    ElementNotInteractableException, ElementNotSelectableException) as e:
                self.info("Caught " + type(e).__name__ + ". Retrying.")
                SelectElementKeywords(self.ctx).select_from_list_by_value(locator, value)

    @keyword
    def if_present_select_from_list_by_label(self, locator, value='default'):
        """
        If select is present (visible and enabled) choose the selected label. No value passed in will leave
        select as default.
        :param locator:
        :param value:
        :return:
        """
        if value == 'default' or value == '':
            return
        if self.is_present(locator):
            self.info("List is present so selecting label '%s'." % value)
            try:
                SelectElementKeywords(self.ctx).select_from_list_by_label(locator, value)
            except (StaleElementReferenceException, ElementClickInterceptedException,
                    ElementNotInteractableException, ElementNotSelectableException) as e:
                self.info("Caught " + type(e).__name__ + ". Retrying.")
                SelectElementKeywords(self.ctx).select_from_list_by_label(locator, value)

    @keyword
    def if_present_select_checkbox(self, locator):
        """
        If the checkbox is present (visible and enabled) select the checkbox.
        :param locator:
        :return:
        """
        if self.is_present(locator):
            self.info("Checkbox is present so checking '%s'." % locator)
            try:
                FormElementKeywords(self.ctx).select_checkbox(locator)
            except (StaleElementReferenceException, ElementClickInterceptedException,
                    ElementNotInteractableException, ElementNotSelectableException) as e:
                self.info("Caught " + type(e).__name__ + ". Retrying.")
                FormElementKeywords(self.ctx).select_checkbox(locator)

    @keyword
    def if_present_unselect_checkbox(self, locator):
        """
        If the checkbox is present (visible and enabled) unselect the checkbox.
        :param locator:
        :return:
        """
        if self.is_present(locator):
            self.info("Checkbox is present so unchecking '%s'." % locator)
            try:
                FormElementKeywords(self.ctx).unselect_checkbox(locator)
            except (StaleElementReferenceException, ElementClickInterceptedException,
                    ElementNotInteractableException, ElementNotSelectableException) as e:
                self.info("Caught " + type(e).__name__ + ". Retrying.")
                FormElementKeywords(self.ctx).unselect_checkbox(locator)

    @keyword
    def if_present_input_text(self, locator, value='default'):
        """
        If the input field is present (visible and enabled) input text
        :param locator:
        :param value:
        :return:
        """
        if value == 'default' or value == '':
            return
        if self.is_present(locator):
            self.info("Textbox is present so entering '%s'." % value)
            try:
                FormElementKeywords(self.ctx).input_text(locator, value)
            except (StaleElementReferenceException, ElementClickInterceptedException,
                    ElementNotInteractableException, ElementNotSelectableException) as e:
                self.info("Caught " + type(e).__name__ + ". Retrying.")
                ElementKeywords(self.ctx).clear_element_text(locator)
                FormElementKeywords(self.ctx).input_text(locator, value)

    @keyword
    def if_present_press_keys(self, locator, *keys):
        """
        If the input field is present (visible and enabled) press keys
        :param locator:
        :return:
        """
        first_item = keys[0]
        if first_item == 'default' or first_item == '':
            return
        if self.is_present(locator):
            self.info("Element is present so sending keys '%s'." % keys)
            try:
                ElementKeywords(self.ctx).press_keys(locator, keys)
            except (StaleElementReferenceException, ElementClickInterceptedException,
                    ElementNotInteractableException, ElementNotSelectableException) as e:
                self.info("Caught " + type(e).__name__ + ". Retrying.")
                ElementKeywords(self.ctx).clear_element_text(locator)
                ElementKeywords(self.ctx).press_keys(locator, keys)

    @keyword
    def if_present_click_element(self, locator):
        """
        If the element is present (visible and enabled) click
        :param locator:
        :return:
        """
        if self.is_present(locator):
            self.info("Element is present so clicking  '%s'." % locator)
            try:
                ElementKeywords(self.ctx).click_element(locator)
            except (StaleElementReferenceException, ElementClickInterceptedException,
                    ElementNotInteractableException, ElementNotSelectableException) as e:
                if self.is_present(locator):
                    self.info("Caught " + type(e).__name__ + ". Retrying.")
                    BrowserKeywordsWait(self.ctx).click_element_with_js(locator, 20, None)


class CustomElementSelect(LibraryComponent):
    def __init__(self, ctx):
        LibraryComponent.__init__(self, ctx)

    @keyword
    def select_or_Unselect_checkbox(self, locator, select):
        """
        Dynamically selects or unselcts a checkbox with the given locator based on the value (Y or N)
        """
        BrowserKeywordsWait(self.ctx).wait_for_js()
        self.info("Selecting '%s' from checkbox '%s'."
                  % (select, locator))
        # element = self._get_checkbox(locator)
        # if (not element.is_selected() and select == 'Y') or (element.is_selected() and select == 'N'):
        #     element.click()
        if select == 'Y':
            try:
                FormElementKeywords(self.ctx).select_checkbox(locator)
            except (StaleElementReferenceException, ElementClickInterceptedException,
                    ElementNotInteractableException, ElementNotSelectableException) as e:
                self.info("Caught " + type(e).__name__ + ". Retrying.")
                element = self.find_element(locator)
                if not element.is_selected():
                    BrowserKeywordsWait(self.ctx).click_element_with_js(locator)

        elif select == 'N':
            try:
                FormElementKeywords(self.ctx).unselect_checkbox(locator)
            except (StaleElementReferenceException, ElementClickInterceptedException,
                    ElementNotInteractableException, ElementNotSelectableException) as e:
                self.info("Caught " + type(e).__name__ + ". Retrying.")
                element = self.find_element(locator)
                if element.is_selected():
                    BrowserKeywordsWait(self.ctx).click_element_with_js(locator)


class UserLibraries(SeleniumLibrary):

    def __init__(self, timeout=5.0, implicit_wait=0.0,
                 run_on_failure='Capture Page Screenshot',
                 screenshot_root_directory=None):
        SeleniumLibrary.__init__(self, timeout=timeout, implicit_wait=implicit_wait,
                                 run_on_failure=run_on_failure,
                                 screenshot_root_directory=screenshot_root_directory)
        self.add_library_components([BrowserKeywordsSign(self), BrowserKeywordsWait(self), ElementPresentAndAct(self),
                                     CustomElementSelect(self), ])


if __name__ == '__main__':
    unittest.main()
